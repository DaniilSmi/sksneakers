from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher import FSMContext
from aiogram.utils.callback_data import CallbackData
import math
from var_dump import var_dump


import forms 
from forms import Price
from forms import Size
from forms import Order
import config as cnf

import datetime

order_info = CallbackData("invite","username","chat_id")

def toFixed(numObj, digits=0):
    return f"{numObj:.{digits}f}"

@cnf.dp.message_handler(lambda message: message.text == cnf.back_btn_text, state='*')
async def cancel_handler(message: types.Message, state: FSMContext):
    current_state = await state.get_state()
    if current_state is None:
        return
    await state.finish()
    await message.answer("<b>📱 Вы в главном меню</b> \n Выберите действие из списка:", reply_markup=cnf.mainMenu, parse_mode="html")

@cnf.dp.message_handler(state=forms.Exchange.Exchange)
async def editExchange(message: types.Message, state: FSMContext):
    await forms.Exchange.Exchange.set()
    async with state.proxy() as data:
      data['Exchange'] = message.text


    number_check = message.text.replace('.', '')

    if number_check.isnumeric():
        number = float(message.text.replace(',', '.'))

        cnf.db.editExchange(number)
        cnf.exchange_yuan = float(number)

        await message.answer("Успешно!")
        await state.finish()
    else:
        await message.answer(text="Введите верное значение ❌", parse_mode="html")
        await forms.Exchange.Exchange.set()



shoes_category = "👟 Обувь"
top_category = "❄️ Куртки, пуховики"
clothes_category = "👕 Футболки, штаны, худи"
technique_category = "📱 Техника"
accessories_category = "📿 Аксессуары"
backpacks_category = "🎒 Рюкзаки"

#Функция расчета стоимости
def calcTotalPrice(cost, category):
   price = cost * cnf.exchange_yuan
   res = 0
   delivery = 0

  #Обувь
   if category == shoes_category:
      delivery = 2000
      if cost <= 3000:
         res = price + 1500
         return res, delivery
      elif cost > 3000:
         res = price + 1500
         return res, delivery
    
   #Куртки-пуховики
   if category == top_category:
      delivery = 1500
      if cost <= 3000:
         res = price + 900
         return res, delivery
      elif cost > 3000:
         res = price + 1300
         return res, delivery
    
   #Футболки, штаны
   if category == clothes_category:
      delivery = 1000
      res = price + 600
      return res, delivery

   #Техника
   if category == technique_category:
      delivery = 1000
      res = price + 2000
      return res, delivery

   #Аксессуары
   if category == accessories_category:
      delivery = 1000
      res = price + 500
      return res, delivery
   
   #Рюкзаки
   if category == backpacks_category:
      delivery = 1000
      res = price + 500
      return res, delivery


def checkRealCategory(category_name):
   if category_name == shoes_category or category_name == top_category or category_name == clothes_category or category_name == technique_category or category_name == accessories_category or category_name == backpacks_category:
      return True
   else:
      return False                                  

#Калькулятор стоимостия
@cnf.dp.message_handler(state=forms.Price.category)
async def calcPrice(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
      data['category'] = message.text
    
    if checkRealCategory(data['category']):
      await message.answer("Введите <b>стоимость товара:</b>", reply_markup=cnf.backMenu, parse_mode="html")
      await Price.next()    
    else:
      await message.answer(text="Введите верное значение ❌", parse_mode="html")
      await Price.category.set()



@cnf.dp.message_handler(state=forms.Price.price)
async def calcPrice(message: types.Message, state: FSMContext):
      async with state.proxy() as data:
        data['price'] = message.text
       
      if message.text.isnumeric():

        checkPrice = calcTotalPrice(cost=int(message.text), category=data['category'])

        cost = checkPrice[0]
        delivery = checkPrice[1]
        
        
        today = datetime.date.today()
        min_date = today + datetime.timedelta(days=10)
        max_date = today + datetime.timedelta(days=13)

        #Inline button
        markup = InlineKeyboardMarkup(row_width=1)
        markup.add(InlineKeyboardButton("Оформить заказ",callback_data=order_info.new(username=message.from_user.username, chat_id=message.chat.id)))

        #Сообщение пользователю
        msg = f"💸 Итоговая стоимость: <b>{toFixed(delivery + cost, 1)}</b>₽ \n\nСтоимость товара - <b>{toFixed(cost, 1)}</b>₽\nСтоимость доставки - <b>{delivery}</b>₽\nКурс ¥ - {cnf.exchange_yuan}\n \n🚚 Будет доставлено:  от <i>{min_date.day}.{min_date.month}</i> до <i>{max_date.day}.{max_date.month}</i> \n \nВаш заказ будет обработан в течение <b>10-15 минут</b>"
        photo = open('img/info/delivery.png', 'rb')
            
        await cnf.bot.send_photo(message.from_user.id, photo, reply_markup=cnf.mainMenu)
        await message.answer(text=msg, reply_markup=markup, parse_mode="html")
          
        await state.finish()
      else:
        await message.answer(text="Введите верное значение ❌", parse_mode="html")
        await Price.price.set()




#Оформление заказа
@cnf.dp.message_handler(state=Order.category)
async def calcPrice(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
      data['category'] = message.text

    if checkRealCategory(data['category']):
      await message.answer(f"<b>🔗 Отправьте ссылку на товар</b> \nНапример: <i>https://dw4.co/t/A/1PbI3PfA</i>", reply_markup=cnf.backMenu, parse_mode="html")
      await Order.next()
    else:
      await message.answer(text="Введите верное значение ❌", parse_mode="html")
      await Order.category.set()



@cnf.dp.message_handler(state=Order.link)
async def calcPrice(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
      data['link'] = message.text

    await message.answer("Введите нужный <b>размер товара:</b>", parse_mode="html")
    await Order.next()
        
@cnf.dp.message_handler(state=Order.size)
async def calcPrice(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
      data['size'] = message.text

    await message.answer("Введите <b>стоимость размера:</b>", parse_mode="html")
    await Order.next()    
    
@cnf.dp.message_handler(state=Order.cost)
async def calcPrice(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
      data['cost'] = message.text

    if message.text.isnumeric():
      await message.answer("Введите ваше <b>ФИО</b>:", parse_mode="html")
      await Order.next()   
    else:
      await message.answer(text="Введите верное значение ❌", parse_mode="html")
      await Order.cost.set()

@cnf.dp.message_handler(state=Order.fio)
async def calcPrice(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
      data['fio'] = message.text

    await message.answer("Введите <b>населенный пункт</b>:", parse_mode="html")
    await Order.next()                     

@cnf.dp.message_handler(state=Order.locality)
async def calcPrice(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
      data['locality'] = message.text

    await message.answer("Введите <b>улицу</b>:", parse_mode="html")
    await Order.next()     

@cnf.dp.message_handler(state=Order.street)
async def calcPrice(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
      data['street'] = message.text

    await message.answer("Введите <b>номер строения</b>:", parse_mode="html")
    await Order.next()      

@cnf.dp.message_handler(state=Order.number_house)
async def calcPrice(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
      data['number_house'] = message.text

    await message.answer("Введите <b>номер квартиры</b>:", parse_mode="html")
    await Order.next()      
             
@cnf.dp.message_handler(state=Order.flat)
async def calcPrice(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
      data['flat'] = message.text

    await message.answer("Введите <b>почтовый индекс</b>:", parse_mode="html")
    await Order.next()      

@cnf.dp.message_handler(state=Order.post_code)
async def calcPrice(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
      data['post_code'] = message.text

    await message.answer("Введите <b>контактный номер телефона</b>:", parse_mode="html")
    await Order.next()  
    
@cnf.dp.message_handler(state=Order.phone)
async def calcPrice(message: types.Message, state: FSMContext):
    if message.text.isnumeric():
      async with state.proxy() as data:
        data['phone'] = message.text

      checkPrice = calcTotalPrice(cost=int(data['cost']), category=data['category'])

      cost = checkPrice[0]
      delivery = checkPrice[1]

      date = datetime.datetime.now()
      today = datetime.date.today()
      min_date = today + datetime.timedelta(days=16)
      max_date = today + datetime.timedelta(days=20)

      #Сообщение пользователю
      msg = f"💸 Итоговая стоимость: <b>{toFixed(delivery + cost, 1)}</b>₽ \n\nСтоимость товара - <b>{toFixed(cost, 1)}</b>₽\nСтоимость доставки - <b>{delivery}</b>₽\nКурс ¥ - {cnf.exchange_yuan}\n \n🚚 Будет доставлено:  от <i>{min_date.day}.{min_date.month}</i> до <i>{max_date.day}.{max_date.month}</i> \n \nВаш заказ будет обработан в течение <b>10-15 минут</b>"
      photo = open('img/info/delivery.png', 'rb')  
      
      await cnf.bot.send_photo(message.from_user.id, photo)
      await message.answer(text=msg, reply_markup=cnf.mainMenu, parse_mode="html")

      #Оповещение 
      msg_admin = f"<b>🌟 Новый заказ!</b> \n \nПользователь: <b>@{message.from_user.username}</b> \nДата и время: <b>{date.day}.{date.month} {date.hour}:{date.minute}</b> \n\n<b>ℹ️ Информация:</b> \nСсылка на товар: <b><a href='{data['link']}'>{data['link']}</a></b> \nРазмер: <b>{data['size']}</b> \nСтоимость: <b>{data['cost']}¥ / {toFixed(cost, 1)}₽</b> \nФИО: <b>{data['fio']}</b> \nНаселенный пункт: <b>{data['locality']}</b> \nУлица: <b>{data['street']}</b> \nНомер строения: <b>{data['number_house']}</b> \nНомер квартиры: <b>{data['flat']}</b> \nИндекс: <b>{data['post_code']}</b> \nНомер телефона: <b>{data['phone']}</b>"                                                                              
      await cnf.bot.send_message(cnf.admin_id, text=msg_admin, parse_mode="html")

      await state.finish()
    else:
      await message.answer(text="Введите верное значение ❌", parse_mode="html")
      await Order.phone.set()


             

@cnf.dp.callback_query_handler(order_info.filter())
#Оформление заказа
async def button_press(call: types.CallbackQuery, callback_data: dict):
        date = datetime.datetime.now()

        #Оповещение 
        msg_admin = f"<b>🌟 Новый заказ!</b> \n \nПользователь: <b>@{callback_data.get('username')}</b> \nДата и время: <b>{date.day}.{date.month} {date.hour}:{date.minute}</b>"
        await cnf.bot.send_message(cnf.admin_id, text=msg_admin, parse_mode="html")

        msg = "<b>🌟 Отлично!</b> \nЗаказ принят в обработку. \n \nМенеджер <a href='https://t.me/sksneakers'>Егор</a> подключится в течение 10-15 минут.."
        await cnf.bot.send_message(callback_data.get('chat_id'), reply_markup=cnf.backMenu, text=msg, parse_mode="html")





