from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher import FSMContext
from database import Database
from aiogram.contrib.fsm_storage.memory import MemoryStorage
import logging

import sqlite3 as sq

import forms 
import functions

# Configure logging
logging.basicConfig(level=logging.INFO)

#bot config
TOKEN_API = "6685892079:AAFW3peqQm2ok850kCNDrmjKyd6uSocOonA"
admin_id = 1056403416 
bot = Bot(TOKEN_API)
dp = Dispatcher(bot,storage=MemoryStorage())
db = Database('data/database.db')


#курс юаня
exchange_yuan = db.getExchange()


#Кнопки

#Главное меню
btn1 = KeyboardButton("🚚 Оформить заказ")
btn2 = KeyboardButton('💸 Рассчитать стоимость')
btn3 = KeyboardButton('🔸 Актуальный курс')
btn4 = KeyboardButton('✅ Отзывы')
btn5 = KeyboardButton('👨‍💻 Поддержка')

mainMenu = ReplyKeyboardMarkup(resize_keyboard = True).row(btn1).row(btn2, btn3).row(btn4, btn5)

#На главную
back_btn_text = "Вернуться к меню"
back_btn = KeyboardButton(back_btn_text)
backMenu = ReplyKeyboardMarkup(resize_keyboard = True).row(back_btn)

