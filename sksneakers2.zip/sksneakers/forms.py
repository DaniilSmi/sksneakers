from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher import FSMContext

class Price(StatesGroup):
	category = State()
	price = State()

class Photo(StatesGroup):
	photo = State()

class Size(StatesGroup):
	category = State()
	Size = State()
	link = State()

class Exchange(StatesGroup):
	Exchange = State()

class Order(StatesGroup):
	category = State()
	link = State()
	size = State()
	cost = State()
	fio = State()
	locality = State()
	street = State()
	number_house = State()
	flat = State()
	post_code = State()
	phone = State()



