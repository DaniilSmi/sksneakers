import telebot
from array import *
from telebot import types
import datetime

#Config
admin_id = 690092896 
bot = telebot.TeleBot('6583115759:AAGmkKGWzHpTei7miIhoxm6MmeamRci1o8Q')

#Start menu
btn1 = types.KeyboardButton("🚚 Оформить заказ")
btn2 = types.KeyboardButton('💸 Рассчитать стоимость')
btn3 = types.KeyboardButton('📷 Найти по фото')
btn4 = types.KeyboardButton('👟 Подобрать размер')
btn5 = types.KeyboardButton('✅ Отзывы')
btn6 = types.KeyboardButton('👨‍💻 Поддержка')

menu = [btn1, btn2, btn3, btn4, btn5, btn6]

btn_back = types.KeyboardButton("Вернуться в меню")

@bot.message_handler(commands=['start'])

def start(message):

    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add(*menu)

    #Оповещение 
    date = datetime.datetime.now()
    bot.send_message(admin_id, f"<b>👨‍💻 Новый пользователь!</b> \n \nПользователь: <b>@{message.from_user.username}</b> \nДата и время: <b>{date.day}.{date.month} {date.hour}:{date.minute}</b>", parse_mode='HTML')

    #Сообщение 
    markdown = f"👋 <b> Здраствуйте, {message.from_user.first_name}!</b> \n \nНаш бот-помощник умеет: \n \n<i>💫 Доставлять товары с POIZON \n💫 Рассчитывать стоимость товара \n💫 Искать товар по фото \n💫 Подбирать <b>точный</b> размер </i>\n \nЧто будем делать?"
    bot.send_message(message.from_user.id, markdown, parse_mode='HTML', reply_markup=markup)



@bot.message_handler(content_types=['text'])

def get_text_messages(message):

    if message.text == 'Вернуться к меню':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        markup.add(*menu)

        markdown = f"<b>📱 Вы в главном меню</b> \n \n Выберите действие:"
        bot.send_message(message.from_user.id, markdown, parse_mode='HTML', reply_markup=markup)

    elif message.text == '💸 Рассчитать стоимость':

        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        markup.add(btn_back)

        video = open('img/video/price.mov', 'rb')
        bot.send_video(message.chat.id, video, timeout=10)
        msg = bot.send_message(message.from_user.id, "Введите стоимость товара <i><b>¥</b></i>", parse_mode='HTML', reply_markup=markup)
        bot.register_next_step_handler(msg, calcPrice)

    elif message.text == '👨‍💻 Поддержка':
        date = datetime.datetime.now()

        bot.send_message(admin_id, f"<b>🌟 Пользователь обращается в поддержку!</b> \n \nПользователь: <b>@{message.from_user.username}</b> \nДата и время: <b>{date.day}.{date.month} {date.hour}:{date.minute}</b>", parse_mode='HTML')
        bot.send_message(message.from_user.id, "<b>👨‍💻 Вы обратились в поддержку</b> \n \nМенеджер <a href='https://t.me/shoezPZ'>Максим</a> подключится в течение 5-10 минут..", parse_mode='HTML')

    elif message.text == '📷 Найти по фото':
        msg = bot.send_message(message.from_user.id, "<b>📷 Найти товар по фото</b> \nПришлите фото, где отчетливо видно товар", parse_mode='HTML')
        bot.register_next_step_handler(msg, findItem)



@bot.message_handler(content_types=['text'])

#Калькулятор стоимости
def calcPrice(message):
    print(message.text.isnumeric())

    if message.text.isnumeric() == True:
        cost = int(message.text) + 99
        result = cost * 13.75

        menu1 = telebot.types.InlineKeyboardMarkup()
        menu1.add(telebot.types.InlineKeyboardButton(text = 'Оформить заказ', callback_data ='first'))


        today = datetime.date.today()
        min_date = today + datetime.timedelta(days=16)
        max_date = today + datetime.timedelta(days=20)

        msg = f"💸 Стоимость товара: <b>{result}</b>₽ \n \nКомиссия - 99¥\nКурс ¥ - 13.75\n \n🚚 Будет доставлено:  от <i>{min_date.day}.{min_date.month}</i> до <i>{max_date.day}.{max_date.month}</i> \n \nВаш заказ будет обработан в течение <b>10-15 минут</b>"

        photo = open('img/info/delivery.png', 'rb')
        bot.send_photo(message.from_user.id, photo)
        bot.send_message(message.from_user.id, msg, reply_markup = menu1, parse_mode='HTML')
        
    else:
        bot.send_message(message.from_user.id, "🚫 Введите верное значение", parse_mode='HTML')





#Найти товар по фото
def findItem(message):
    bot.forward_message(admin_id, message.chat.id, message.message_id)

    date = datetime.datetime.now()

    #Оповещение
    msg = f"<b>📷 Пользователь хочет найти товар по фото!</b> \n \nПользователь: <b>@{message.from_user.username}</b> \nДата и время: <b>{date.day}.{date.month} {date.hour}:{date.minute}</b>"
    bot.send_message(admin_id, msg, parse_mode='HTML')

    #Сообщение пользователю
    msg_user = "<b>🖼 Выполняется поиск по фото</b> \n \nМенеджер <a href='https://t.me/shoezPZ'>Максим</a> подключится в течение 5-10 минут.."
    bot.send_message(message.from_user.id, msg_user, parse_mode='HTML')




@bot.callback_query_handler(func=lambda call: True)
def step2(call):  
    if call.data == 'first':
        msg = "<b>🌟 Отлично!</b> \nЗаказ принят в обработку. \n \nМенеджер <a href='https://t.me/shoezPZ'>Максим</a> подключится в течение 5-10 минут.."
        
        date = datetime.datetime.now()

        #Опопвещение
        bot.send_message(admin_id, f"<b>🌟 Новый заказ!</b> \n \nПользователь: <b>@{call.from_user.username}</b> \nДата и время: <b>{date.day}.{date.month} {date.hour}:{date.minute}</b>", parse_mode='HTML')
        
        #Сообщение пользователю
        bot.send_message(call.message.chat.id, msg, parse_mode='HTML')




bot.polling(none_stop=True)