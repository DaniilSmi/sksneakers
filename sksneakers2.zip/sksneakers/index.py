from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher import FSMContext
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.utils.callback_data import CallbackData

import sqlite3 as sq
from database import Database

import forms 
from forms import Price
from forms import Photo
from forms import Order
from forms import Size
from forms import Exchange

import functions as fn
import config as cnf

import datetime


@cnf.dp.message_handler(commands=['start'])
async def start(message: types.Message):

    print(cnf.exchange_yuan)

    date = datetime.datetime.now()

    markdown = f"👋 <b> Здраствуйте, {message.from_user.first_name}!</b>\n \n➡️ Вы запустили бота <i><b>SKSNEAKER</b></i> \n\n<b>👉 Выберите действие из списка:</b>\n- Рассчитать стоимость \n- Оформить доставку с <b>POIZON</b> \n- Посмотреть актуальный курс \n- Увидеть отзывы \n- Поддержка"                                                              
    await message.answer(text=markdown, reply_markup=cnf.mainMenu, parse_mode="html")
    await cnf.bot.send_message(cnf.admin_id, text=f"<b>👨‍💻 Новый пользователь!</b> \n \nПользователь: <b>@{message.from_user.username}</b> \nДата и время: <b>{date.day}.{date.month} {date.hour}:{date.minute}</b>", parse_mode="html")


@cnf.dp.message_handler(content_types=['text'])
async def get_text_messages(message: types.Message):

    if message.text == '🚚 Оформить заказ':

        msg = "Выберите категорию товара:"
        
        btn_cl1 = KeyboardButton("👟 Обувь")
        btn_cl2 = KeyboardButton('❄️ Куртки, пуховики')
        btn_cl3 = KeyboardButton('👕 Футболки, штаны, худи')
        btn_cl4 = KeyboardButton('📱 Техника')
        btn_cl5 = KeyboardButton('📿 Аксессуары')
        btn_cl6 = KeyboardButton('🎒 Рюкзаки')
        btn_cl7 = KeyboardButton(cnf.back_btn_text)


        clothesMenu = ReplyKeyboardMarkup(resize_keyboard = True).row(btn_cl1, btn_cl2).row(btn_cl3, btn_cl4).row(btn_cl5, btn_cl6).row(btn_cl7)

        await message.answer(text=msg, reply_markup=clothesMenu, parse_mode="html")

        await Order.category.set()
    
    elif message.text == cnf.back_btn_text:
        msg = "<b>📱 Вы в главном меню</b> \n Выберите действие из списка:"
        await message.answer(text=msg, reply_markup=cnf.mainMenu, parse_mode="html")

    elif message.text == "Курс":
        if message.from_user.id == cnf.admin_id:
            await message.answer(f"Введите актуальный курс", parse_mode="html")

            await Exchange.Exchange.set()
        else:
            await message.answer("У вас недостаточно прав для выполнения этой команды!")
               
    elif message.text == "💸 Рассчитать стоимость":
        msg = "Выберите категорию товара:"

        btn_cl1 = KeyboardButton("👟 Обувь")
        btn_cl2 = KeyboardButton('❄️ Куртки, пуховики')
        btn_cl3 = KeyboardButton('👕 Футболки, штаны, худи')
        btn_cl4 = KeyboardButton('📱 Техника')
        btn_cl5 = KeyboardButton('📿 Аксессуары')
        btn_cl6 = KeyboardButton('🎒 Рюкзаки')
        btn_cl7 = KeyboardButton(cnf.back_btn_text)


        clothesMenu = ReplyKeyboardMarkup(resize_keyboard = True).row(btn_cl1, btn_cl2).row(btn_cl3, btn_cl4).row(btn_cl5, btn_cl6).row(btn_cl7)

        #Send message 
        await message.answer(text=msg, reply_markup=clothesMenu, parse_mode="html")

        await Price.category.set()

    elif message.text == "🔸 Актуальный курс":
        msg = f"<b>Актуальный курс</b>\n<i>1¥</i> = <i>{cnf.exchange_yuan}₽</i>"
        await message.answer(text=msg, reply_markup=cnf.mainMenu, parse_mode="html")

    elif message.text == '👨‍💻 Поддержка':
        date = datetime.datetime.now()

        await cnf.bot.send_message(cnf.admin_id, text=f"<b>🌟 Пользователь обращается в поддержку!</b> \n \nПользователь: <b>@{message.from_user.username}</b> \nДата и время: <b>{date.day}.{date.month} {date.hour}:{date.minute}</b>", parse_mode="html")
        await message.answer(text="<b>👨‍💻 Вы обратились в поддержку</b> \n \nМенеджер <a href='https://t.me/sksneakers'>Егор</a> подключится в течение 10-15 минут..", parse_mode="html")

    elif message.text == '✅ Отзывы':
        await message.answer(text="<b>✅ Отзывы</b> \n \n<a href='https://t.me/otzyvysks'>Наш канал с отзывами</a>", parse_mode="html")

        





if __name__ == '__main__':
    executor.start_polling(cnf.dp)

