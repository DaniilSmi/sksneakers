from array import *
import sqlite3

class Database:
    def __init__(self, db_file):
        self.connection = sqlite3.connect(db_file, check_same_thread=False)
        self.cursor = self.connection.cursor()

    def getExchange(self):
        res = self.cursor.execute("SELECT * FROM `info` WHERE id == 1").fetchone()
        return res[1]
    
    def editExchange(self, exchange):
          with self.connection:
              query = self.cursor.execute("UPDATE info  SET 'exchange_yuan' = {} WHERE id == 1".format(exchange))
              print(query, exchange)